#22 Se tienen tres baldes de agua, uno de cinco litros, otro de tres litros y otro de un litro; Si el de un litro tarda una hora y media en llenarse, resuelva cuanto tiempo pueden tardar en llenarse los otros baldes. 
# Si tiene tres baldes, pero se desconoce su tamaño debe de resolver igualmente el ejercicio.

Tiempo_por_Litro = 1.5 
Tiempo_5L = 5 * Tiempo_por_Litro
Tiempo_3L = 3 * Tiempo_por_Litro

print(f"Tiempo para llenar el balde de 5 litros: {Tiempo_5L} horas")
print(f"Tiempo para llenar el balde de 3 litros: {Tiempo_3L} horas")
print(f"Tiempo para llenar el balde de 1 litro: {Tiempo_por_Litro} horas")
