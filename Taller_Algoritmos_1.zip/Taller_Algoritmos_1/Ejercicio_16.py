#16 Suponga que un conductor le pide a usted que le haga un algoritmo para calcular cuánto le corresponde en un día trabajado, teniendo en cuenta que tiene derecho a el 19% del total recaudado.

Recaudado = float(input("Ingrese el total recaudado en el día: "))
print(f"El total que le corresponde al conductor es: {Recaudado * 0.19}")
