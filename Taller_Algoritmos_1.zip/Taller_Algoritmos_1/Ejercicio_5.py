#5 Lea la distancia (En kilómetros) recorrida por un auto, el tiempo (En horas) en que la recorrió y calcule la velocidad a la cual se desplazaba el auto (V=D/T).

Distancia = float(input("Ingrese la distancia recorrida en Kilómetros: "))
Tiempo = float(input("Ingrese el tiempo en horas que se demoró en recorrer la distancia: "))

print(f"La velocidad a la cual se desplazaba el auto es: {Distancia / Tiempo} Km/h")
