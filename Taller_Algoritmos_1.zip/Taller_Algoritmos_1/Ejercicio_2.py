#2 Lea dos números y calcule el resultado de su suma, resta, multiplicación y división.

Primero = int(input("Ingrese el primer numero: "))
Segundo = int(input("Ingrese el segundo numero: "))

print(f"El resultado de la suma es: {Primero + Segundo}")
print(f"El resultado de la resta es: {Primero - Segundo}")
print(f"El resultado de la multiplicación es: {Primero * Segundo}")
print(f"El resultado de la división es: {Primero / Segundo}")
