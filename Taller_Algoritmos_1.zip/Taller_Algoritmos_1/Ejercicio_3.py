#3 Dadas las 3 notas de un aprendiz, calcule la definitiva de la asignatura.

Notas = [3, 4, 5]
Promedio = 0

for i in Notas: 
    Promedio += i
print("La nota definitiva del aprendiz es: ", Promedio / 3)
