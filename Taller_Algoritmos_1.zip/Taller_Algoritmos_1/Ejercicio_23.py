#23 Una persona tarda 5 horas en subir una montaña de 7 metros, si un escalador desea subir más o menos de la montaña, cuanto tiempo tarda en subir. Debe de resolver el ejercicio.

Metros = float(input("¿Cuántos metros desea subir?: "))
HxM = (5/7) * 60
print("Te tardas aproximadamente: ", ((HxM * Metros)/60), " horas en subir la montaña")
