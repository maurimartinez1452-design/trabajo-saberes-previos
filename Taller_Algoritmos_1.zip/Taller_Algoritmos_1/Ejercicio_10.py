#10 Una tienda ofrece un descuento del 15% sobre el total de la compra y un cliente desea saber cuánto deberá pagar finalmente por su compra.

Total = float(input("¿Cuánto es el total a pagar?: "))
print(f"El total a pagar con el descuento del 15% es: {Total - (Total * 0.15)}")
