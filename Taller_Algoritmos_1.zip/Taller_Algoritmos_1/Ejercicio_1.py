#1 Lea tres números y calcule el resultado de su suma.

Primero = float(input("Ingrese el primer numero: "))
Segundo = float(input("Ingrese el segundo numero: "))
Tercero = float(input("Ingrese el tercer numero: "))

Resultado = Primero + Segundo + Tercero
print("El resultado de la suma es: ", Resultado)
