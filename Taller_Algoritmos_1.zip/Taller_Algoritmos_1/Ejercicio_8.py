#8 Suponga que un individuo desea invertir su capital en un banco y desea saber cuánto dinero ganará después de un mes si el banco paga a razón de 2% mensual.

Inversión = float(input("De cuánto será su inversión?: "))
print(f"Esto retornara el 2% mensual: {Inversión * 0.02}")
