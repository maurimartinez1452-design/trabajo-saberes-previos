#13 Dada las horas trabajadas de una persona y el valor por hora. Calcular su salario e imprimirlo.

Horas = float(input("Ingrese las horas trabajadas: "))
Valor_Hora = float(input("Ingrese el valor por hora: "))

print("El salario es: ", Horas * Valor_Hora)
